Link Icons
* Icons for links based on protocol or file type.






Usage
----------------------------------------------------------------

1) Add this line to your HTML:
	 <link rel="stylesheet" href="css/blueprint/plugins/link-icons/screen.css" type="text/css" media="screen, projection">	